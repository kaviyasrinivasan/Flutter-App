package com.example.age_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
