import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Age Calculator',
      // Apply a light blue color scheme
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
        scaffoldBackgroundColor: Colors.white, // Set background color
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.lightBlue, // Set app bar color
          foregroundColor: Colors.white, // Set text color for app bar
        ),
        textTheme: const TextTheme(
          headlineLarge: TextStyle(fontSize: 40, color: Colors.black), // Style for "Your age is"
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String myAge = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Age Calculator"),
        centerTitle: true,
      ),
    body: Center(

    //padding: const EdgeInsets.all(280.0),
    child: Column(
    mainAxisAlignment: MainAxisAlignment.center, // Center widgets vertically
    children: [
    const Text(
    'Your age is',
        style: const TextStyle(fontSize: 30,color:Colors.blue)

    ),
    const SizedBox(
    height: 30,
    ),
    Text(myAge, style: const TextStyle(fontSize: 30)),
    const SizedBox(
    height: 40,
    ),
    ElevatedButton(
    onPressed: () => pickDob(context),
    child: const Text('Select your Date of Birth'),
    style: ElevatedButton.styleFrom(
    backgroundColor: Colors.lightBlueAccent,
    ),
    )
    ],
    ),
    ));
  }

  pickDob(BuildContext context) {
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    ).then((pickedDate) {
      if (pickedDate != null) {
        calculateAge(pickedDate);
      }
    });
  }

  void calculateAge(DateTime birth) {
    DateTime now = DateTime.now();

    int years = now.year - birth.year;
    int months = now.month - birth.month;
    int days = now.day - birth.day;

    // If days are negative, adjust the month and days
    if (days < 0) {
      months--;
      // Adding days of the previous month to the days
      days += DateTime(now.year, now.month, 0).day;
    }

    // If months are negative, adjust the years and months
    if (months < 0) {
      years--;
      months += 12;
    }

    setState(() {
      myAge = '$years years, $months months, and $days days';
    });
  }
}
